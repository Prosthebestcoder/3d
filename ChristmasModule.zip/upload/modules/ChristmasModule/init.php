<?php
/**
 * CHRISTMAS MODULE | By zJerino & VertisanPRO
 * Version: 1.0.1
 */

$cmLanguage = new Language(__DIR__ . '/language', LANGUAGE);
require_once "module.php";