# Suggestions Module for NamelessMC v2.2.0

## Installation:
- Upload the contents of the **upload** directory straight into your NamelessMC installation's directory
- Activate the module in the StaffCP -> Modules tab

## Subscribe:
If you like to help out with the development of my modules there is a link where you can subscribe a monthly amount [https://partydragen.com/subscribe/](https://partydragen.com/subscribe/)

## NamelessHosting:
Create your own free NamelessMC website at NamelessHosting for free at [https://namelesshosting.com](https://namelesshosting.com/)

## Contact me:
- Discord: [https://discord.gg/cY5Yfzd](https://discord.gg/cY5Yfzd)
- Website: [https://partydragen.com](https://partydragen.com)