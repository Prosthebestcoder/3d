<?php

class NotificationTypeNotFoundException extends Exception {}
