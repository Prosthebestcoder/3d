<?php

const EMAIL_MAX_LENGTH = 75000;
